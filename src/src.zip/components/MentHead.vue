

<!--
 * @Author: 熊小兜
 * @Date: 2019-11-12 19:13:43
 * @LastEditors: losn
 * @LastEditTime: 2019-11-26 11:55:55
 * @Description: 
 -->
<template>
    <div class="box">
        <div class="bigBox">
            <div class="circle" onClick={}>圈子</div>
            <div class="circle">热门</div>
            <div class="circle">引力</div>
            <div class="circle">关注</div>
        </div>
        <img class="man" src="../assets/img/man.jpg" alt="">
    </div> 
</template>
<script>

export default {
    name:"MentHead",
     data(){
        return {
         
        }
    }
}
</script>
<style lang="scss"    scoped>
.bigBox{
    width: 80%;
    margin-left: .3rem;
    height: .7rem;
    // background-color: pink;
    display: flex;
    justify-content: space-around;
    position: relative;
    .circle{
        width: 20%;
        height: .6rem;
        // background-color: red;
        font-size: .2rem;
        text-align: center;
        line-height: .6rem;
        font-weight: 600;
    }
}
.man{
    width: .4rem;
    height: .4rem;
    position: absolute;
    right: 0.05rem;
    top: .3rem;
}
</style>