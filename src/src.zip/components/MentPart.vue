

<!--
 * @Author: 熊小兜
 * @Date: 2019-11-12 19:13:43
 * @LastEditors: losn
 * @LastEditTime: 2019-11-26 20:10:39
 * @Description: 
 -->
<template>     
    <div class="box">
        <div class="bigBox">
            <div>
                潮人社区
            </div>
            <div>
                发售日历
            </div>
        </div>
    </div> 
</template>
<script>

export default {
    name:"MentPart",
     data(){
        return {
        
        }
    }
}
</script>
<style lang="scss"    scoped>

</style>